package is.ru.droid.testapp.db;

/**
 * A collection of role constants
 */
public class Roles {
    public static final String ADMIN = "ADMIN";
    public static final String NORMAL = "NORMAL";
}
