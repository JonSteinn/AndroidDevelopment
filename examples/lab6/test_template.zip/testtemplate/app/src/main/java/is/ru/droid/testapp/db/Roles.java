package is.ru.droid.testapp.db;

/**
 * Created by Jonni on 11/27/2017.
 */

public class Roles {
    public static final String ADMIN = "ADMIN";
    public static final String NORMAL = "NORMAL";
}
