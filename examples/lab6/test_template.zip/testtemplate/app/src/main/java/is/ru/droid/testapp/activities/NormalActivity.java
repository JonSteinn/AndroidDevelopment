package is.ru.droid.testapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import java.util.Locale;

import is.ru.droid.testapp.R;
import is.ru.droid.testapp.util.BinaryConverter;

/**
 * A screen where the user can click 0 and 1 to create
 * a binary string on the screen. Once its length reaches
 * 8, we calculate its integer value and display that too.
 * Then the next click would restart the process so a
 * binary string would never exceed the length of 8.
 */
public class NormalActivity extends AppCompatActivity {

    // String as a fixed char array of length 8 and a current index
    private char[] str;
    private int index;

    // Display variable
    private TextView binary;

    /**
     * Sets variables and checks for intents.
     *
     * @param savedInstanceState old instance
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_normal);

        // Intent to say hello to the user
        Intent intent = getIntent();
        String name = intent.getStringExtra("SESSION");
        if (name != null) {
            TextView tv = findViewById(R.id.greeting);
            tv.setText(getString(R.string.welcome_messages, name));
        }

        // set variables
        binary = findViewById(R.id.binary);
        str = new char[8];
        resetString();
    }

    /**
     * Adds the next binary digit to the screen.
     *
     * @param view the button that triggered the event
     */
    public void addNext(View view) {
        // If we have a string of length 8, we reset it
        if (index == -1) resetString();

        // 0 and 1 button cases, sets the next value in the string
        // to the appropriate value and decreases the index by one
        switch(view.getId()) {
            case R.id.btn0:
                str[index--] = '0';
                break;
            case R.id.btn1:
                str[index--] = '1';
                break;
        }

        // If we have reached a length of 8 we calculate the integer value of the string
        // and add it to the display. Otherwise we just refresh the string with the
        // newly added value.
        if (index == -1) {
            String s = new String(str);
            binary.setText(String.format(Locale.US, "%s = %d", s, BinaryConverter.toInt(s)));
        } else {
            binary.setText(new String(str));
        }
    }

    /**
     * Set whitespace to all array elements, being invisible when displayed.
     */
    private void resetString() {
        for (int i = 0; i < 8; i++) {
            str[i] = ' ';
        }
        index = 7;
    }
}
