package is.ru.droid.testapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import is.ru.droid.testapp.R;
import is.ru.droid.testapp.db.Roles;
import is.ru.droid.testapp.db.User;
import is.ru.droid.testapp.db.UserDao;
import is.ru.droid.testapp.db.UserDatabase;

/**
 * A simple login screen where the login and sign up share text fields.
 */
public class LoginActivity extends AppCompatActivity {

    // Views
    private EditText un;
    private EditText pw;
    private Button login;
    private Button signUp;

    // Database instance
    private UserDatabase db;

    /**
     * Setup callback. Only sets variables.
     *
     * @param savedInstanceState old instance
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        setVariables();
    }

    /**
     * As soon as screen comes back into foreground
     * we clear any existing error messages.
     */
    @Override
    protected void onResume() {
        super.onResume();

        // Clear old error messages
        clearAllErrors();
    }

    /**
     * Destroy callback. Cleaning up database.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        db = null;
        UserDatabase.closeDb();
    }

    /**
     * Set instance variables.
     */
    private void setVariables() {
        db = UserDatabase.getInstance(this);
        un = findViewById(R.id.un);
        pw = findViewById(R.id.pw);
        login = findViewById(R.id.login);
        signUp = findViewById(R.id.sign_up);
    }

    /**
     * Run every time we try to set up.
     *
     * @param view the sign up button
     */
    public void attemptSignUp(View view) {
        // Clear old error messages
        clearAllErrors();

        // Lock buttons
        setButtonClickable(false);

        // String format of input fields
        String username = un.getText().toString();
        String password = pw.getText().toString();

        // Check if non-empty
        if (!validInput(username, password)) {
            // Unlock buttons and stop attempt
            setButtonClickable(true);
            return;
        }

        // Get data access object
        UserDao dao = db.userDao();

        if (dao.getUserByName(username) == null) {

            // Add new user to db, all as ROLE=NORMAL
            dao.addUsers(new User(username, password, Roles.NORMAL));

            // set intent for next activity
            Intent intent = new Intent(this, NormalActivity.class);
            intent.putExtra("SESSION", un.getText().toString());

            // Unlock buttons
            setButtonClickable(true);

            // go from this activity to the next
            startActivity(intent);
        } else {

            // Set error message
            un.setFocusable(true);
            un.setError(getString(R.string.in_use));

            // Unlock buttons
            setButtonClickable(true);
        }

    }

    public void attemptLogin(View view) {
        // Clear old error messages
        clearAllErrors();

        // Lock buttons
        setButtonClickable(false);

        // String format of input fields
        String username = un.getText().toString();
        String password = pw.getText().toString();

        // Check if non-empty
        if (!validInput(username, password)) {
            // Unlock buttons and stop attempt
            setButtonClickable(true);
            return;
        }

        // Get data access object and get user by username
        UserDao dao = db.userDao();
        User user = dao.getUserByName(username);

        // If it does not exist, set errors and stop
        if (user == null) {
            // set error
            un.setFocusable(true);
            un.setError(getString(R.string.no_user));

            // unlock buttons and leave
            setButtonClickable(true);
            return;
        }

        if (!password.equals(user.getPassword())) {
            // If password is invalid

            // set error messages
            pw.setFocusable(true);
            pw.setError(getString(R.string.wrong_pass));

            // Unlock buttons
            setButtonClickable(true);

        } else if (Roles.ADMIN.equals(user.getRole())) {
            // If user is admin

            // set intent for next activity
            Intent intent = new Intent(this, AdminActivity.class);

            // Unlock buttons
            setButtonClickable(true);

            // go from this activity to the next
            startActivity(intent);
        } else {
            // If user is not admin (normal user)

            // set intent for next activity
            Intent intent = new Intent(this, NormalActivity.class);
            intent.putExtra("SESSION", un.getText().toString());


            // Unlock buttons
            setButtonClickable(true);

            // go from this activity to the next
            startActivity(intent);
        }
    }

    /**
     * Input validator without db access.
     *
     * @param username
     * @param password
     * @return
     */
    private boolean validInput(String username, String password) {
        // Get error message from resources
        String req = getString(R.string.required);

        // If username empty
        if (username.trim().length() == 0) {
            un.setError(req);
            un.setFocusable(true);
            return false;
        }

        // If password empty
        if (password.trim().length() == 0) {
            pw.setError(req);
            pw.setFocusable(true);
            return false;
        }

        // If neither is invalid
        return true;
    }

    /**
     * Locks or unlocks the buttons.
     *
     * @param clickable true for unlocking, false for locking
     */
    private void setButtonClickable(boolean clickable) {
        login.setClickable(clickable);
        signUp.setClickable(clickable);
    }

    /**
     * Clears all errors and focus on text views.
     */
    private void clearAllErrors() {
        un.clearFocus();
        pw.clearFocus();
        un.setError(null);
        pw.setError(null);
    }
}
