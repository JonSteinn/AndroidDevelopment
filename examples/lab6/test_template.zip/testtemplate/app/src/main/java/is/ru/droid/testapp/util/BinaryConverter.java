package is.ru.droid.testapp.util;

/**
 * Collection of util methods for binary conversion.
 */
public final class BinaryConverter {
    /**
     * Private constructor so it is impossible to create an instance of the class.
     */
    private BinaryConverter() { }

    /**
     * Converts a binary string of length 8 to
     * a its unsigned integer representation.
     *
     * @param str binary string of length 8
     * @return integer value of the binary string
     * @throws IllegalArgumentException if string is not a binary string of length 8
     */
    public static int toInt(String str) throws IllegalArgumentException {
        if (isOfLength8(str) && isBinaryString(str)) {
            int sum = 0;
            for (int i = 0; i < 8; i++) {
                sum += numericCharToInt(str.charAt(7 - i)) * (1 << i);
            }
            return sum;
        } else {
            throw new IllegalArgumentException();
        }
    }

    /**
     * Converts a numeric char ('0', '1', ..., '9') to
     * there corresponding int value 0, 1, ..., 9.
     *
     * @param c numeric char
     * @return integer representation of char
     * @throws IllegalArgumentException if char is not numeric
     */
    public static int numericCharToInt(char c) throws IllegalArgumentException {
        if (c < '0' || c > '9') throw new IllegalArgumentException();
        return c - '0';
    }

    /**
     * Check if string is of length 8.
     *
     * @param str any string
     * @return true iff str is not null and of length 8
     */
    public static boolean isOfLength8(String str) {
        return str != null && str.length() == 8;
    }

    /**
     * Check if string contains nothing but 0 and 1.
     *
     * @param str any string
     * @return true if str only contains 0 and 1
     */
    public static boolean isBinaryString(String str) {
        return str.matches("[01]+");
    }
}
