package is.ru.droid.testapp.db;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

/**
 * Database builder.
 */
@Database(entities = User.class, version = 1, exportSchema = false)
public abstract class UserDatabase extends RoomDatabase {
    public abstract UserDao userDao();

    // Singleton instance
    private static UserDatabase INSTANCE = null;

    /**
     * Threadsafe getter for singleton database.
     *
     * @param context any context
     * @return the database instance in use
     */
    public static UserDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (UserDatabase.class) {
                if (INSTANCE == null) {
                    // Allowing main thread queries since this is just for testing
                    INSTANCE = Room
                            .databaseBuilder(context, UserDatabase.class, "user.db")
                            .allowMainThreadQueries()
                            .build();
                    // Add some initial values if empty
                    UserDao dao = INSTANCE.userDao();
                    if (dao.getAllUsers().size() == 0) {
                        dao.addUsers(
                            new User("MASTER_ADMIN", "0", Roles.ADMIN),
                            new User("Luke", "1", Roles.NORMAL),
                            new User("Leia", "2", Roles.NORMAL),
                            new User("Han", "3", Roles.NORMAL)
                        );
                    }
                }
            }
        }
        return INSTANCE;
    }

    /**
     * Free the resources of the singleton instance.
     */
    public static void closeDb() {
        if (INSTANCE != null) {
            synchronized (UserDatabase.class) {
                if (INSTANCE != null) {
                    INSTANCE.close();
                    INSTANCE = null;
                }
            }
        }
    }
}
