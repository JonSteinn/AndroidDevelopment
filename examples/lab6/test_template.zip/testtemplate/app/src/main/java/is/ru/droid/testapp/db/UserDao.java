package is.ru.droid.testapp.db;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import java.util.List;

/**
 * Data access object.
 */
@Dao
public interface UserDao {

    /**
     * Adds a User to the database and use REPLACE conflict strategy.
     * See more <a href="https://sqlite.org/lang_conflict.html">here</a>.
     *
     * @param user User arguments
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addUsers(User... user);

    /**
     * Get every user currently in the database.
     *
     * @return A list of every user in the database.
     */
    @Query("SELECT * FROM USERS")
    List<User> getAllUsers();

    /**
     * Get a single user by their primary key.
     *
     * @param username username column of the desired db entry
     * @return a User instance of the database entry with given username, null if non-existing.
     */
    @Query("SELECT * FROM USERS WHERE USERNAME = :username LIMIT 1")
    User getUserByName(String username);
}
